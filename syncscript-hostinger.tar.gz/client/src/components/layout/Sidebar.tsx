import { NavLink } from 'react-router-dom'
import { 
  LayoutDashboard, 
  CheckSquare, 
  Calendar, 
  DollarSign, 
  Settings,
  Brain,
  Trophy,
  Bell,
  User,
  ExternalLink,
  Zap
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuthStore } from '@/stores/authStore'
import { useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Tasks', href: '/tasks', icon: CheckSquare },
  { name: 'Calendar', href: '/calendar', icon: Calendar },
  { name: 'Google Calendar', href: '/google-calendar', icon: ExternalLink },
  { name: 'Financial', href: '/financial', icon: DollarSign },
  { name: 'AI Assistant', href: '/ai-assistant', icon: Brain },
  { name: 'Energy Analysis', href: '/energy-analysis', icon: Zap },
  { name: 'Profile', href: '/profile', icon: User },
  { name: 'Gamification', href: '/gamification', icon: Trophy },
  { name: 'Notifications', href: '/notifications', icon: Bell },
  { name: 'Settings', href: '/settings', icon: Settings },
]

export function Sidebar() {
  const { user } = useAuthStore()
  const queryClient = useQueryClient()

  const prefetchData = (href: string) => {
    if (!user) return

        // Only prefetch if data is not already cached or is stale
        const shouldPrefetch = (queryKey: string[]) => {
          const query = queryClient.getQueryData(queryKey)
          const queryState = queryClient.getQueryState(queryKey)
          return !query || (queryState && queryState.dataUpdatedAt < Date.now() - 5 * 60 * 1000)
        }

    switch (href) {
      case '/dashboard':
        if (shouldPrefetch(['dashboard'])) {
          queryClient.prefetchQuery({
            queryKey: ['dashboard'],
            queryFn: async () => {
              const response = await api.get('/user/dashboard')
              return response.data.data
            },
            staleTime: 10 * 60 * 1000,
          })
        }
        break
      case '/tasks':
        if (shouldPrefetch(['tasks'])) {
          queryClient.prefetchQuery({
            queryKey: ['tasks'],
            queryFn: async () => {
              const response = await api.get('/tasks')
              return response.data.data
            },
            staleTime: 10 * 60 * 1000,
          })
        }
        break
      case '/calendar':
        if (shouldPrefetch(['events'])) {
          queryClient.prefetchQuery({
            queryKey: ['events'],
            queryFn: async () => {
              const response = await api.get('/calendar')
              return response.data.data
            },
            staleTime: 10 * 60 * 1000,
          })
        }
        break
      case '/google-calendar':
        if (shouldPrefetch(['google-calendar-status'])) {
          queryClient.prefetchQuery({
            queryKey: ['google-calendar-status'],
            queryFn: async () => {
              const response = await api.get('/google-calendar/status')
              return response.data.data
            },
            staleTime: 10 * 60 * 1000,
          })
        }
        break
      case '/gamification':
        if (shouldPrefetch(['gamification'])) {
          queryClient.prefetchQuery({
            queryKey: ['gamification'],
            queryFn: async () => {
              const response = await api.get('/gamification')
              return response.data.data
            },
            staleTime: 5 * 60 * 1000,
          })
        }
        break
    }
  }

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">SyncScript</h1>
            <p className="text-xs text-muted-foreground">AI Life Manager</p>
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-primary">
              {user?.name?.charAt(0) || user?.email?.charAt(0) || 'U'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {user?.name || 'User'}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user?.email}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            onMouseEnter={() => prefetchData(item.href)}
            className={({ isActive }) =>
              cn(
                'flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              )
            }
          >
            <item.icon className="w-5 h-5" />
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="text-xs text-muted-foreground text-center">
          <p>SyncScript v1.0.0</p>
          <p>Powered by AI</p>
        </div>
      </div>
    </div>
  )
}
